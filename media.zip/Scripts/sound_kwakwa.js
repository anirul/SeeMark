if (fattycurd.parameter_set["kwakwa_begin"] === "<unknown>"){
	fattycurd.sound.play("logo_kwakwa", false);
	fattycurd.parameter_set["kwakwa_begin"] = JSON.stringify(true);	
}
	