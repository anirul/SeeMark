if (fattycurd.parameter_set["dorian_begin"] === "<unknown>"){
	fattycurd.sound.play("logo_dorian", false);
	fattycurd.parameter_set["dorian_begin"] = JSON.stringify(true);	
}
	